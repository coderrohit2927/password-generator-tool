
  // Function to generate a random password
  function generatePassword() {
    // Get password length
    const passwordLength = parseInt(document.getElementById("password-length").value);

    // Define character sets
    const uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const lowercaseLetters = "abcdefghijklmnopqrstuvwxyz";
    const numbers = "0123456789";
    const symbols = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";

    // Determine which character sets to include
    let characterSet = "";
    if (document.getElementById("include-uppercase").checked) {
      characterSet += uppercaseLetters;
    }
    if (document.getElementById("include-lowercase").checked) {
      characterSet += lowercaseLetters;
    }
    if (document.getElementById("include-numbers").checked) {
      characterSet += numbers;
    }
    if (document.getElementById("include-symbols").checked) {
      characterSet += symbols;
    }

    // Generate password
    let password = "";
    for (let i = 0; i < passwordLength; i++) {
      password += characterSet.charAt(Math.floor(Math.random() * characterSet.length));
    }

    // Display password
    const passwordOutput = document.getElementById("password-output");
    passwordOutput.innerHTML = password;

    // Enable copy button
    const copyButton = document.getElementById("copy-button");
    copyButton.disabled = false;
  }

  // Function to copy the password to the clipboard
  function copyPassword() {
    const passwordOutput = document.getElementById("password-output");
    const range = document.createRange();
    range.selectNode(passwordOutput);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(range);
    document.execCommand("copy");
    window.getSelection().removeAllRanges();
  }

  // Event listener for generate button
  const generateButton = document.getElementById("generate-button");
  generateButton.addEventListener("click", function(event) {
    event.preventDefault();
    generatePassword();
  });

  // Event listener for copy button
  const copyButton = document.getElementById("copy-button");
  copyButton.addEventListener("click", function(event) {
    event.preventDefault();
    copyPassword();
  });

